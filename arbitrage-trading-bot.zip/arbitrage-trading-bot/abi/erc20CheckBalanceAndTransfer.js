module.exports = [
    {
        constant: false,
        inputs: [
            { name: "_to", type: "address" },
            { name: "_value", type: "uint256" },
        ],
        name: "transfer",
        outputs: [{ name: "", type: "bool" }],
        type: "function",
    },

    {
        constant: true,
        inputs: [{"name": "_owner", "type": "address"}],
        name: "balanceOf",
        outputs: [{"name":"balance", "type": "uint256"}],
        type: "function"
    },
    
    {
        constant: true,
        inputs: [],
        name: "decimals",
        outputs: [{"name": "", "type": "uint8"}],
        type: "function"
    }
];